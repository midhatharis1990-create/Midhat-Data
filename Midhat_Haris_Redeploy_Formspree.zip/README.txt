DEPLOYMENT NOTES

1. Open index.html.
2. Find:
   https://formspree.io/f/YOUR_FORM_ID
3. Replace YOUR_FORM_ID with the Formspree form ID from your working portfolio.
   Do NOT change the rest of the URL.
4. Upload index.html to Vercel.

The HTML includes:
- Responsive mobile layout
- Power BI prominently included
- Case studies and proof
- Required form validation
- Protection against rapid duplicate submissions
- Formspree AJAX submission
- SEO title and description
- Open Graph + Twitter metadata
- Current canonical URL: https://midhatproject.vercel.app/

If you already have a working Formspree endpoint in your old HTML, copy that exact endpoint into the new file.
